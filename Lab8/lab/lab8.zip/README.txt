Hello, I just wanted to be clear about how I structured this lab.

in my main.c file, i implemented a list of flights to test the output of my functions.

I did not modify either LinkedList.h or LinkedList.c files.
I did, however, modify lab8.h to accommodate helper functions in my lab8.c code. they are separated from the grading scope.
I implemented them in lab8.c in the bottom portion, which is indicated with comments.

Lab8.c and main.c are my implementations of this lab

LinkedList.c/.h is given code.
